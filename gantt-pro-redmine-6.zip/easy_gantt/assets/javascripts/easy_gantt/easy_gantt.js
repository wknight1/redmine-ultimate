/*
 * = require_directory ./libs
 * = require easy_gantt/utils
 * = require easy_gantt/data
 * = require easy_gantt/widget
 * = require_directory .
 * = stub easy_gantt/sample
 * = stub easy_gantt/libs/moment
*/