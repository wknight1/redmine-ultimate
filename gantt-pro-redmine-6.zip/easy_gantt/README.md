# Easy Gantt

For documentation and requirements, go to https://www.easyredmine.com/redmine-gantt-plugin
