class EasyGanttSuppressNotification < ActiveSupport::CurrentAttributes
  attribute :value
end