class EditorHooks < Redmine::Hook::ViewListener
    def view_layouts_base_body_bottom(context)
      content = ""
  
      if User.current.allowed_to?(:edit_issues, context[:project])
        content << javascript_include_tag('issue_editor.js', :plugin => :inplace_issue_editor)
        content << stylesheet_link_tag('issue_editor.css', :plugin => :inplace_issue_editor)
        content << javascript_include_tag('issue_edit_configuration.js', :plugin => :inplace_issue_editor)
      end
  
      content << <<~JS.html_safe
        <script>
          document.addEventListener("DOMContentLoaded", function() {
            const logoutLink = document.querySelector(".logout");
            if (logoutLink) {
              logoutLink.addEventListener("click", function(event) {
                if (this.dataset.clicked) {
                  event.preventDefault(); 
                  return false;
                }
                this.dataset.clicked = "true"; 
                this.style.pointerEvents = "none"; 
              });
            }
          });
        </script>
      JS
  
      content.html_safe
    end
  end
  