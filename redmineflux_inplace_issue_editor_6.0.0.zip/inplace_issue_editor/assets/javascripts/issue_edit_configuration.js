/*
 * _CONF_FORCE_HTTPS (boolean)
 * Will force AJAX call performed by the plugin to be done with https protocol
 * Use this value if you encounter some difficulties with "Mixed content" issues
 * Allowed values : false (default), true
 */
var _CONF_FORCE_HTTPS = true;