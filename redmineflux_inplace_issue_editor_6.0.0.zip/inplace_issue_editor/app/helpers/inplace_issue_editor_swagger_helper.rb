module InplaceIssueEditorSwaggerHelper
end
