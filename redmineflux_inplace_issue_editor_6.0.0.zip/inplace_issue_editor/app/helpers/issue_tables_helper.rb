module IssueTablesHelper
end
