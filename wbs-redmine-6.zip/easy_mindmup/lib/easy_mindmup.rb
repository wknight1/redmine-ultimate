module EasyMindmup
end
