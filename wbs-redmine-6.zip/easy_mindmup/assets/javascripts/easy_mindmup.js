/*
 * = require color
 * = require mustache
 * = require hammer
 * = require jquery.hammer
 * = require jquery.hotkeys
 * = require underscore
 * = require mindmup/mapjs
 * = require_directory ./mindmup
 * = require libs
 * = require polyfill
 * = require utils
 * = require_directory .
 * = stub mindmup/link-edit-widget
 * = stub jsdocs_external
 */
